export const ProductRequestAction = data => ({
    type: "PRODUCT_REQUEST",
    payload: data,
});